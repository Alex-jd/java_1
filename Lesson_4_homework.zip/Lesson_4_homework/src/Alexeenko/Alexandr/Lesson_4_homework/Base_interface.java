package Alexeenko.Alexandr.Lesson_4_homework;

/**
 * Created by Alex_JD on 14.11.2015.
 */
public interface Base_interface {
    public void propertySkill ();

}
