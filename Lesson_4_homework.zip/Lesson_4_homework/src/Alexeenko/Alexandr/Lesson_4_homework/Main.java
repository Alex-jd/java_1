package Alexeenko.Alexandr.Lesson_4_homework;

public class Main {

    public static void main(String[] args) {
	// write your code here
    }



}
